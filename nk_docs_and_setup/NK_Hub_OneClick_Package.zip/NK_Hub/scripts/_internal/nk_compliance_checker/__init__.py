# -*- coding: utf-8 -*-
"""Pacchetto interno per il verificatore di conformita NK Hub Generation."""

from __future__ import annotations

import pkgutil

__path__ = pkgutil.extend_path(__path__, __name__)
