"""Pacchetto interno SBFL Engine."""
