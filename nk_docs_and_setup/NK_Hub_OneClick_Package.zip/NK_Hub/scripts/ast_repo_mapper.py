"""
Nexus Keystone v4.8.0-STE100-Unified: High-Density AST Repo-Map Engine
Module: scripts/ast_repo_mapper.py
Author: NK-Python-Async-Builder (CRV 4.0 Macro-Fase 1)

Key Capabilities:
- Genera il grafo dei simboli (Python AST e Polyglot JS/TS/CSS/HTML).
- Calcola Personalized PageRank (d=0.85) con vettore di teletrasporto multi-focale.
- Esegue lo slicing chirurgico Karpathy preservando i parametri esatti.
- Applica il clustering gerarchico a due livelli contro la diluizione dei token.
- Gestisce la cache incrementale per file (nodi ed archi) con rename atomico in %TEMP%.
- Adatta il budget token per skill (Mode C/B/A e profili Argon).
- Esporta autonomamente lo snapshot in nk_genome/repo_map.md.
"""

from __future__ import annotations

import argparse
import ast
import json
import math
import os
import re
import sys
import tempfile
import time
import uuid
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from pydantic import BaseModel, ConfigDict, Field


# ============================================================================
# PYDANTIC V2 STRICT DATA MODELS
# ============================================================================

class SymbolType(str, Enum):
    MODULE = "MODULE"
    CLASS = "CLASS"
    METHOD = "METHOD"
    FUNCTION = "FUNCTION"
    ASYNC_FUNCTION = "ASYNC_FUNCTION"
    CONSTANT = "CONSTANT"
    IMPORT = "IMPORT"
    TYPE_ALIAS = "TYPE_ALIAS"
    JS_COMPONENT = "JS_COMPONENT"
    CSS_RULE = "CSS_RULE"


class EdgeType(str, Enum):
    CALL = "CALL"
    INHERITANCE = "INHERITANCE"
    TYPE_REFERENCE = "TYPE_REFERENCE"
    IMPORT_USAGE = "IMPORT_USAGE"
    CONTAINMENT = "CONTAINMENT"
    ATTRIBUTE_ACCESS = "ATTRIBUTE_ACCESS"


class SymbolNode(BaseModel):
    model_config = ConfigDict(strict=False, frozen=True)

    id: str = Field(description="Identificatore univoco qualificato del simbolo")
    name: str = Field(description="Nome breve del simbolo")
    symbol_type: SymbolType = Field(description="Categoria del simbolo di codice")
    module_path: str = Field(description="Percorso relativo del modulo o file")
    parent_id: Optional[str] = Field(default=None, description="ID del contenitore padre")
    line_start: int = Field(ge=1, description="Riga iniziale (1-indexed)")
    line_end: int = Field(ge=1, description="Riga finale (1-indexed)")
    signature: Optional[str] = Field(default=None, description="Rappresentazione completa della firma")
    docstring: Optional[str] = Field(default=None, description="Docstring estratta")
    return_type: Optional[str] = Field(default=None, description="Annotazione del tipo di ritorno")
    is_async: bool = Field(default=False, description="Indica se la funzione e' asincrona")
    raw_source: Optional[str] = Field(default=None, description="Frammento di codice sorgente originale")


class SymbolEdge(BaseModel):
    model_config = ConfigDict(strict=False, frozen=True)

    source_id: str = Field(description="ID del simbolo sorgente")
    target_id: str = Field(description="ID del simbolo destinazione")
    edge_type: EdgeType = Field(description="Categoria della relazione")
    weight: float = Field(default=1.0, ge=0.0, description="Peso dell'arco per PageRank")


class SymbolGraph(BaseModel):
    model_config = ConfigDict(strict=True)

    nodes: Dict[str, SymbolNode] = Field(default_factory=dict, description="Mappa dei nodi per ID")
    edges: List[SymbolEdge] = Field(default_factory=list, description="Archi diretti tra simboli")
    adjacency_out: Dict[str, List[Tuple[str, float]]] = Field(
        default_factory=dict, description="Lista di adiacenza in uscita"
    )
    adjacency_in: Dict[str, List[Tuple[str, float]]] = Field(
        default_factory=dict, description="Lista di adiacenza in ingresso"
    )

    def add_node(self, node: SymbolNode) -> None:
        self.nodes[node.id] = node
        if node.id not in self.adjacency_out:
            self.adjacency_out[node.id] = []
        if node.id not in self.adjacency_in:
            self.adjacency_in[node.id] = []

    def add_edge(self, edge: SymbolEdge) -> None:
        self.edges.append(edge)
        if edge.source_id not in self.adjacency_out:
            self.adjacency_out[edge.source_id] = []
        if edge.target_id not in self.adjacency_in:
            self.adjacency_in[edge.target_id] = []
        self.adjacency_out[edge.source_id].append((edge.target_id, edge.weight))
        self.adjacency_in[edge.target_id].append((edge.source_id, edge.weight))


class PageRankResult(BaseModel):
    model_config = ConfigDict(strict=True)

    scores: Dict[str, float] = Field(description="Mappa ID simbolo e punteggio PageRank")
    ranked_symbols: List[Tuple[str, float]] = Field(description="Lista ordinata decrescente")
    iterations: int = Field(description="Numero di iterazioni fino a convergenza")
    converged: bool = Field(description="Indica se la convergenza sotto epsilon e' raggiunta")


class SliceResult(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True)

    sliced_code: str = Field(description="Codice sorgente ridotto chirurgicamente")
    token_count: int = Field(description="Stima dei token")
    focal_symbols: List[str] = Field(description="ID dei simboli focali preservati per intero")
    collapsed_symbols: List[str] = Field(description="ID dei simboli compressi in firme scheletro")
    omitted_symbols: List[str] = Field(description="ID dei simboli a bassa rilevanza omessi")
    compression_ratio: float = Field(description="Rapporto tra caratteri ridotti e originali")


class RepoMapConfig(BaseModel):
    model_config = ConfigDict(strict=True)

    max_tokens: int = Field(default=1024, ge=128, le=4096, description="Tetto massimo del budget token")
    mode: str = Field(default="auto", description="Modalita' esecuzione: auto, mode_c, mode_b, mode_a")
    cache_enabled: bool = Field(default=True, description="Abilita la cache atomica su disco")
    cache_dir: Optional[str] = Field(default=None, description="Directory personalizzata per la cache")
    polyglot: bool = Field(default=True, description="Include contratti frontend JS/TS/CSS/HTML")
    focal_files: List[str] = Field(default_factory=list, description="Percorsi dei file focali target")
    focal_symbols: List[str] = Field(default_factory=list, description="Nomi dei simboli focali target")


class RepoMapResult(BaseModel):
    model_config = ConfigDict(strict=True)

    content: str = Field(description="Contenuto Markdown della Repo-Map")
    token_count: int = Field(description="Conteggio stimato dei token <= max_tokens")
    files_scanned: int = Field(description="Totale dei file analizzati o letti da cache")
    cached_hits: int = Field(description="Conteggio dei file serviti dalla cache incrementale")
    elapsed_ms: float = Field(description="Tempo totale di generazione in millisecondi")
    focal_files: List[str] = Field(default_factory=list, description="File focali prioritizzati")


# ============================================================================
# TOKEN ESTIMATOR
# ============================================================================

def estimate_tokens(text: str) -> int:
    """
    Stima il numero di token in modo deterministico compatibile con BPE.
    Combina la frammentazione lessicale con la lunghezza in caratteri.
    """
    if not text:
        return 0
    pattern = re.compile(r"\w+|[^\w\s]", re.UNICODE)
    tokens = pattern.findall(text)
    char_estimate = int(math.ceil(len(text) / 3.5))
    return max(len(tokens), char_estimate)


# ============================================================================
# RESILIENT CST / AST PARSER
# ============================================================================

class ResilientParser:
    """
    Analizza il codice sorgente resistendo a errori intermedi di sintassi.
    Preserva i token parziali dei parametri senza emettere firme vuote.
    """

    @classmethod
    def parse_safe(cls, source: str, filename: str = "<string>") -> Tuple[Optional[ast.AST], List[str]]:
        warnings: List[str] = []
        try:
            tree = ast.parse(source, filename=filename)
            return tree, warnings
        except SyntaxError as se:
            warnings.append(f"SyntaxError on line {se.lineno}, col {se.offset}: {se.msg}")

        sanitized_tree = cls._recover_ast_chunks(source, filename, warnings)
        return sanitized_tree, warnings

    @classmethod
    def _recover_ast_chunks(cls, source: str, filename: str, warnings: List[str]) -> Optional[ast.AST]:
        lines = source.splitlines(keepends=True)
        if not lines:
            return ast.parse("")

        block_ranges: List[Tuple[int, int]] = []
        start_idx = 0
        for i in range(1, len(lines)):
            line = lines[i]
            if line and not line[0].isspace() and not line.strip().startswith("#"):
                block_ranges.append((start_idx, i))
                start_idx = i
        block_ranges.append((start_idx, len(lines)))

        valid_nodes: List[ast.stmt] = []
        for b_start, b_end in block_ranges:
            block_code = "".join(lines[b_start:b_end])
            try:
                sub_tree = ast.parse(block_code, filename=filename)
                for node in sub_tree.body:
                    cls._offset_linenos(node, b_start)
                    valid_nodes.append(node)
            except SyntaxError as block_se:
                warnings.append(
                    f"Recovering malformed block at lines {b_start+1}-{b_end}: {block_se.msg}"
                )
                stub_nodes = cls._extract_stubs_from_broken_block(block_code, b_start)
                valid_nodes.extend(stub_nodes)

        mod = ast.Module(body=valid_nodes, type_ignores=[])
        return mod

    @classmethod
    def _offset_linenos(cls, node: ast.AST, offset: int) -> None:
        for child in ast.walk(node):
            if hasattr(child, "lineno"):
                child.lineno += offset  # type: ignore[misc]
            if hasattr(child, "end_lineno") and child.end_lineno is not None:
                child.end_lineno += offset  # type: ignore[misc]

    @classmethod
    def _extract_stubs_from_broken_block(cls, block_code: str, line_offset: int) -> List[ast.stmt]:
        stubs: List[ast.stmt] = []
        lines = block_code.splitlines()
        for idx, line in enumerate(lines):
            stripped = line.strip()
            fn_match = re.match(r"^(async\s+)?def\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\((.*?)(?:\)|:|$)", stripped)
            if fn_match:
                is_async = bool(fn_match.group(1))
                fn_name = fn_match.group(2)
                raw_params = fn_match.group(3).strip()
                cur_line = line_offset + idx + 1
                try:
                    param_names = [p.split(":")[0].strip() for p in raw_params.split(",") if p.strip()]
                    cleaned_params = [p for p in param_names if re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", p)]
                    param_sig = ", ".join(cleaned_params)
                    stub_src = f"{'async ' if is_async else ''}def {fn_name}({param_sig}): pass"
                    stub_tree = ast.parse(stub_src)
                    fn_node = stub_tree.body[0]
                    fn_node.lineno = cur_line
                    fn_node.end_lineno = cur_line + 1
                    stubs.append(fn_node)
                except Exception:
                    pass
                continue

            cls_match = re.match(r"^class\s+([a-zA-Z_][a-zA-Z0-9_]*)(\(.*?\))?:", stripped)
            if cls_match:
                cls_name = cls_match.group(1)
                cur_line = line_offset + idx + 1
                try:
                    stub_src = f"class {cls_name}: pass"
                    stub_tree = ast.parse(stub_src)
                    c_node = stub_tree.body[0]
                    c_node.lineno = cur_line
                    c_node.end_lineno = cur_line + 1
                    stubs.append(c_node)
                except Exception:
                    pass
        return stubs


# ============================================================================
# SYMBOL EXTRACTOR (PYTHON AST)
# ============================================================================

class SymbolExtractor(ast.NodeVisitor):
    """
    Estrae i simboli strutturati e le relazioni di dipendenza dall'AST.
    """

    def __init__(self, module_path: str, source_lines: List[str]):
        self.module_path = str(module_path).replace("\\", "/")
        self.source_lines = source_lines
        self.graph = SymbolGraph()
        self.current_class_id: Optional[str] = None
        self.current_scope_id: Optional[str] = None
        self.symbol_name_to_ids: Dict[str, Set[str]] = {}
        self.scope_calls: Dict[str, Set[str]] = {}

    def _register_name_mapping(self, name: str, symbol_id: str) -> None:
        if name not in self.symbol_name_to_ids:
            self.symbol_name_to_ids[name] = set()
        self.symbol_name_to_ids[name].add(symbol_id)

    def _get_raw_source(self, start_line: int, end_line: int) -> str:
        s = max(0, start_line - 1)
        e = min(len(self.source_lines), end_line)
        return "".join(self.source_lines[s:e])

    def _format_signature(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
        is_async = isinstance(node, ast.AsyncFunctionDef)
        prefix = "async def " if is_async else "def "
        args_str = self._format_arguments(node.args)
        ret_ann = ""
        if node.returns:
            try:
                ret_ann = f" -> {ast.unparse(node.returns)}"
            except Exception:
                ret_ann = ""
        return f"{prefix}{node.name}({args_str}){ret_ann}"

    def _format_arguments(self, args: ast.arguments) -> str:
        parts: List[str] = []
        posonly = getattr(args, "posonlyargs", [])
        for arg in posonly:
            ann = f": {ast.unparse(arg.annotation)}" if arg.annotation else ""
            parts.append(f"{arg.arg}{ann}")
        if posonly:
            parts.append("/")

        num_defaults = len(args.defaults)
        offset = len(args.args) - num_defaults
        for i, arg in enumerate(args.args):
            ann = f": {ast.unparse(arg.annotation)}" if arg.annotation else ""
            default_idx = i - offset
            if default_idx >= 0 and default_idx < len(args.defaults):
                try:
                    def_val = ast.unparse(args.defaults[default_idx])
                    parts.append(f"{arg.arg}{ann}={def_val}")
                except Exception:
                    parts.append(f"{arg.arg}{ann}=...")
            else:
                parts.append(f"{arg.arg}{ann}")

        if args.vararg:
            ann = f": {ast.unparse(args.vararg.annotation)}" if args.vararg.annotation else ""
            parts.append(f"*{args.vararg.arg}{ann}")
        elif args.kwonlyargs:
            parts.append("*")

        for i, arg in enumerate(args.kwonlyargs):
            ann = f": {ast.unparse(arg.annotation)}" if arg.annotation else ""
            kw_def = args.kw_defaults[i]
            if kw_def is not None:
                try:
                    def_val = ast.unparse(kw_def)
                    parts.append(f"{arg.arg}{ann}={def_val}")
                except Exception:
                    parts.append(f"{arg.arg}{ann}=...")
            else:
                parts.append(f"{arg.arg}{ann}")

        if args.kwarg:
            ann = f": {ast.unparse(args.kwarg.annotation)}" if args.kwarg.annotation else ""
            parts.append(f"**{args.kwarg.arg}{ann}")

        return ", ".join(parts)

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            sym_id = f"{self.module_path}:import_{alias.name}"
            sym_node = SymbolNode(
                id=sym_id,
                name=alias.name,
                symbol_type=SymbolType.IMPORT,
                module_path=self.module_path,
                line_start=node.lineno,
                line_end=getattr(node, "end_lineno", node.lineno),
                signature=f"import {alias.name}" + (f" as {alias.asname}" if alias.asname else ""),
                raw_source=self._get_raw_source(node.lineno, getattr(node, "end_lineno", node.lineno)),
            )
            self.graph.add_node(sym_node)
            self._register_name_mapping(alias.asname or alias.name, sym_id)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        mod = node.module or ""
        for alias in node.names:
            sym_id = f"{self.module_path}:import_{mod}.{alias.name}"
            sym_node = SymbolNode(
                id=sym_id,
                name=alias.name,
                symbol_type=SymbolType.IMPORT,
                module_path=self.module_path,
                line_start=node.lineno,
                line_end=getattr(node, "end_lineno", node.lineno),
                signature=f"from {mod} import {alias.name}" + (f" as {alias.asname}" if alias.asname else ""),
                raw_source=self._get_raw_source(node.lineno, getattr(node, "end_lineno", node.lineno)),
            )
            self.graph.add_node(sym_node)
            self._register_name_mapping(alias.asname or alias.name, sym_id)
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        if self.current_scope_id is None or self.current_scope_id == self.current_class_id:
            for target in node.targets:
                if isinstance(target, ast.Name) and (target.id.isupper() or self.current_class_id is None):
                    sym_id = (
                        f"{self.current_class_id}.{target.id}"
                        if self.current_class_id
                        else f"{self.module_path}:{target.id}"
                    )
                    sym_node = SymbolNode(
                        id=sym_id,
                        name=target.id,
                        symbol_type=SymbolType.CONSTANT,
                        module_path=self.module_path,
                        parent_id=self.current_class_id,
                        line_start=node.lineno,
                        line_end=getattr(node, "end_lineno", node.lineno),
                        signature=f"{target.id} = ...",
                        raw_source=self._get_raw_source(node.lineno, getattr(node, "end_lineno", node.lineno)),
                    )
                    self.graph.add_node(sym_node)
                    self._register_name_mapping(target.id, sym_id)
                    if self.current_class_id:
                        self.graph.add_edge(
                            SymbolEdge(
                                source_id=self.current_class_id,
                                target_id=sym_id,
                                edge_type=EdgeType.CONTAINMENT,
                                weight=1.0,
                            )
                        )
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        class_id = (
            f"{self.current_class_id}.{node.name}"
            if self.current_class_id
            else f"{self.module_path}:{node.name}"
        )
        doc = ast.get_docstring(node)
        bases_str = ", ".join(ast.unparse(b) for b in node.bases) if node.bases else ""
        sig = f"class {node.name}({bases_str}):" if bases_str else f"class {node.name}:"

        sym_node = SymbolNode(
            id=class_id,
            name=node.name,
            symbol_type=SymbolType.CLASS,
            module_path=self.module_path,
            parent_id=self.current_class_id,
            line_start=node.lineno,
            line_end=getattr(node, "end_lineno", node.lineno),
            signature=sig,
            docstring=doc,
            raw_source=self._get_raw_source(node.lineno, getattr(node, "end_lineno", node.lineno)),
        )
        self.graph.add_node(sym_node)
        self._register_name_mapping(node.name, class_id)

        for base in node.bases:
            base_name = ast.unparse(base)
            if base_name in self.symbol_name_to_ids:
                for target_id in self.symbol_name_to_ids[base_name]:
                    self.graph.add_edge(
                        SymbolEdge(
                            source_id=class_id,
                            target_id=target_id,
                            edge_type=EdgeType.INHERITANCE,
                            weight=2.0,
                        )
                    )

        prev_class = self.current_class_id
        prev_scope = self.current_scope_id
        self.current_class_id = class_id
        self.current_scope_id = class_id

        self.generic_visit(node)

        self.current_class_id = prev_class
        self.current_scope_id = prev_scope

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._process_function(node, is_async=False)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._process_function(node, is_async=True)

    def _process_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef, is_async: bool) -> None:
        if self.current_class_id:
            fn_id = f"{self.current_class_id}.{node.name}"
            sym_type = SymbolType.METHOD
        else:
            fn_id = f"{self.module_path}:{node.name}"
            sym_type = SymbolType.ASYNC_FUNCTION if is_async else SymbolType.FUNCTION

        doc = ast.get_docstring(node)
        sig = self._format_signature(node)
        ret_type = ast.unparse(node.returns) if node.returns else None

        sym_node = SymbolNode(
            id=fn_id,
            name=node.name,
            symbol_type=sym_type,
            module_path=self.module_path,
            parent_id=self.current_class_id,
            line_start=node.lineno,
            line_end=getattr(node, "end_lineno", node.lineno),
            signature=sig,
            docstring=doc,
            return_type=ret_type,
            is_async=is_async,
            raw_source=self._get_raw_source(node.lineno, getattr(node, "end_lineno", node.lineno)),
        )
        self.graph.add_node(sym_node)
        self._register_name_mapping(node.name, fn_id)

        if self.current_class_id:
            self.graph.add_edge(
                SymbolEdge(
                    source_id=self.current_class_id,
                    target_id=fn_id,
                    edge_type=EdgeType.CONTAINMENT,
                    weight=1.5,
                )
            )

        for arg in node.args.args + getattr(node.args, "posonlyargs", []) + node.args.kwonlyargs:
            if arg.annotation:
                ann_str = ast.unparse(arg.annotation)
                self._link_type_references(fn_id, ann_str)
        if node.returns:
            self._link_type_references(fn_id, ast.unparse(node.returns))

        prev_scope = self.current_scope_id
        self.current_scope_id = fn_id

        self.generic_visit(node)
        if fn_id in self.scope_calls:
            self.scope_calls[fn_id].discard(node.name)

        self.current_scope_id = prev_scope

    def _link_type_references(self, source_id: str, type_str: str) -> None:
        tokens = re.findall(r"[a-zA-Z_][a-zA-Z0-9_]*", type_str)
        for token_name in tokens:
            if token_name in self.symbol_name_to_ids:
                for target_id in self.symbol_name_to_ids[token_name]:
                    if target_id != source_id:
                        self.graph.add_edge(
                            SymbolEdge(
                                source_id=source_id,
                                target_id=target_id,
                                edge_type=EdgeType.TYPE_REFERENCE,
                                weight=1.0,
                            )
                        )

    def visit_Call(self, node: ast.Call) -> None:
        if self.current_scope_id:
            callee_name: Optional[str] = None
            if isinstance(node.func, ast.Name):
                callee_name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                callee_name = node.func.attr

            if callee_name:
                self.scope_calls.setdefault(self.current_scope_id, set()).add(
                    callee_name
                )
            if callee_name and callee_name in self.symbol_name_to_ids:
                for target_id in self.symbol_name_to_ids[callee_name]:
                    if target_id != self.current_scope_id:
                        self.graph.add_edge(
                            SymbolEdge(
                                source_id=self.current_scope_id,
                                target_id=target_id,
                                edge_type=EdgeType.CALL,
                                weight=1.5,
                            )
                        )
        self.generic_visit(node)


# ============================================================================
# POLYGLOT PARSER (JS, TS, HTML, CSS)
# ============================================================================

class PolyglotExtractor:
    """
    Estrae in modo deterministico i contratti frontend da JS, TS, CSS e HTML.
    """

    @classmethod
    def extract_symbols(cls, file_path: str, content: str) -> List[SymbolNode]:
        clean_path = file_path.replace("\\", "/")
        ext = Path(file_path).suffix.lower()
        nodes: List[SymbolNode] = []

        if ext in (".js", ".ts", ".jsx", ".tsx"):
            nodes.extend(cls._extract_js_ts(clean_path, content))
        elif ext == ".css":
            nodes.extend(cls._extract_css(clean_path, content))
        elif ext in (".html", ".htm"):
            nodes.extend(cls._extract_html(clean_path, content))

        return nodes

    @classmethod
    def _extract_js_ts(cls, path: str, content: str) -> List[SymbolNode]:
        nodes: List[SymbolNode] = []
        lines = content.splitlines()

        fn_pattern = re.compile(
            r"^(?:export\s+)?(?:async\s+)?function\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*\((.*?)\)",
            re.MULTILINE
        )
        cls_pattern = re.compile(
            r"^(?:export\s+)?class\s+([a-zA-Z_$][a-zA-Z0-9_$]*)(?:\s+extends\s+([a-zA-Z_$][a-zA-Z0-9_$]*))?",
            re.MULTILINE
        )
        const_fn_pattern = re.compile(
            r"^(?:export\s+)?const\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=\s*(?:async\s*)?\((.*?)\)\s*=>",
            re.MULTILINE
        )

        for idx, line in enumerate(lines, start=1):
            m_fn = fn_pattern.search(line)
            if m_fn:
                name = m_fn.group(1)
                params = m_fn.group(2).strip()
                sig = f"function {name}({params}): ..."
                nodes.append(SymbolNode(
                    id=f"{path}:{name}",
                    name=name,
                    symbol_type=SymbolType.FUNCTION,
                    module_path=path,
                    line_start=idx,
                    line_end=idx,
                    signature=sig,
                    raw_source=line.strip()
                ))
                continue

            m_cls = cls_pattern.search(line)
            if m_cls:
                name = m_cls.group(1)
                parent = m_cls.group(2)
                sig = f"class {name}" + (f" extends {parent}" if parent else "") + ": ..."
                nodes.append(SymbolNode(
                    id=f"{path}:{name}",
                    name=name,
                    symbol_type=SymbolType.CLASS,
                    module_path=path,
                    line_start=idx,
                    line_end=idx,
                    signature=sig,
                    raw_source=line.strip()
                ))
                continue

            m_const = const_fn_pattern.search(line)
            if m_const:
                name = m_const.group(1)
                params = m_const.group(2).strip()
                sig = f"const {name} = ({params}) => ..."
                nodes.append(SymbolNode(
                    id=f"{path}:{name}",
                    name=name,
                    symbol_type=SymbolType.FUNCTION,
                    module_path=path,
                    line_start=idx,
                    line_end=idx,
                    signature=sig,
                    raw_source=line.strip()
                ))

        return nodes

    @classmethod
    def _extract_css(cls, path: str, content: str) -> List[SymbolNode]:
        nodes: List[SymbolNode] = []
        rules = re.findall(r"([.#][a-zA-Z0-9_-]+)\s*\{", content)
        seen = set()
        for idx, rule in enumerate(rules[:30], start=1):
            if rule not in seen:
                seen.add(rule)
                nodes.append(SymbolNode(
                    id=f"{path}:{rule}",
                    name=rule,
                    symbol_type=SymbolType.CSS_RULE,
                    module_path=path,
                    line_start=idx,
                    line_end=idx,
                    signature=f"{rule} {{ ... }}",
                    raw_source=f"{rule} {{ ... }}"
                ))
        return nodes

    @classmethod
    def _extract_html(cls, path: str, content: str) -> List[SymbolNode]:
        nodes: List[SymbolNode] = []
        ids = re.findall(r'id=["\']([a-zA-Z0-9_-]+)["\']', content)
        seen = set()
        for idx, elem_id in enumerate(ids[:20], start=1):
            if elem_id not in seen:
                seen.add(elem_id)
                nodes.append(SymbolNode(
                    id=f"{path}:#{elem_id}",
                    name=f"#{elem_id}",
                    symbol_type=SymbolType.JS_COMPONENT,
                    module_path=path,
                    line_start=idx,
                    line_end=idx,
                    signature=f'<... id="{elem_id}">',
                    raw_source=f'id="{elem_id}"'
                ))
        return nodes


# ============================================================================
# PERSONALIZED PAGERANK ALGORITHM (d = 0.85)
# ============================================================================

class PersonalizedPageRank:
    """
    Calcola Personalized PageRank su un SymbolGraph con fattore di smorzamento d=0.85.
    Concentra il vettore di teletrasporto sui simboli focali target.
    """

    @classmethod
    def compute(
        cls,
        graph: SymbolGraph,
        target_symbol_ids: Optional[Set[str]] = None,
        damping: float = 0.85,
        max_iter: int = 100,
        epsilon: float = 1e-6,
    ) -> PageRankResult:
        nodes = list(graph.nodes.keys())
        n = len(nodes)
        if n == 0:
            return PageRankResult(scores={}, ranked_symbols=[], iterations=0, converged=True)

        node_index = {node_id: idx for idx, node_id in enumerate(nodes)}

        v = [0.0] * n
        valid_targets = [tid for tid in (target_symbol_ids or set()) if tid in node_index]
        if valid_targets:
            teleport_prob = 1.0 / len(valid_targets)
            for tid in valid_targets:
                v[node_index[tid]] = teleport_prob
        else:
            uniform_prob = 1.0 / n
            v = [uniform_prob] * n

        out_weights = [0.0] * n
        for src_id, edges in graph.adjacency_out.items():
            if src_id in node_index:
                src_idx = node_index[src_id]
                out_weights[src_idx] = sum(w for _, w in edges)

        p = list(v)
        converged = False
        iteration = 0

        for iteration in range(1, max_iter + 1):
            p_next = [0.0] * n
            dangling_sum = 0.0

            for i in range(n):
                node_id = nodes[i]
                if out_weights[i] > 0.0:
                    for target_id, weight in graph.adjacency_out.get(node_id, []):
                        if target_id in node_index:
                            t_idx = node_index[target_id]
                            p_next[t_idx] += damping * p[i] * (weight / out_weights[i])
                else:
                    dangling_sum += p[i]

            teleport_contrib = (1.0 - damping) + damping * dangling_sum
            for i in range(n):
                p_next[i] += teleport_contrib * v[i]

            diff = sum(abs(p_next[i] - p[i]) for i in range(n))
            p = p_next
            if diff < epsilon:
                converged = True
                break

        total_p = sum(p)
        if total_p > 0.0:
            p = [x / total_p for x in p]

        scores = {nodes[i]: p[i] for i in range(n)}
        ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)

        return PageRankResult(
            scores=scores,
            ranked_symbols=ranked,
            iterations=iteration,
            converged=converged,
        )


# ============================================================================
# MULTI-FOCAL SURGICAL SLICER & TWO-TIER CLUSTERING
# ============================================================================

class KarpathySurgicalSlicer:
    """
    Esegue lo slicing chirurgico Karpathy con ricerca binaria semantica.
    Preserva tutti i simboli focali per intero e rispetta il limite max_tokens.
    """

    TOKEN_BUDGET: int = 780

    @classmethod
    def slice_module(
        cls,
        source_code: str,
        focal_symbol_names: List[str],
        module_path: str = "module.py",
        max_tokens: int = TOKEN_BUDGET,
    ) -> SliceResult:
        source_lines = source_code.splitlines(keepends=True)
        tree, _ = ResilientParser.parse_safe(source_code, filename=module_path)

        extractor = SymbolExtractor(module_path=module_path, source_lines=source_lines)
        if tree:
            extractor.visit(tree)
        graph = extractor.graph

        focal_ids: Set[str] = set()
        for focal_name in focal_symbol_names:
            if focal_name in extractor.symbol_name_to_ids:
                focal_ids.update(extractor.symbol_name_to_ids[focal_name])
            elif focal_name in graph.nodes:
                focal_ids.add(focal_name)
            else:
                for sid in graph.nodes:
                    if focal_name in sid:
                        focal_ids.add(sid)

        pr_result = PersonalizedPageRank.compute(graph, target_symbol_ids=focal_ids)

        non_focal_ranked = [
            (sid, score) for sid, score in pr_result.ranked_symbols
            if sid not in focal_ids and graph.nodes[sid].symbol_type != SymbolType.IMPORT
        ]

        best_slice: Optional[str] = None
        best_tokens = 0
        best_collapsed: List[str] = []
        best_omitted: List[str] = []

        for include_docs in (True, False):
            low = 0
            high = len(non_focal_ranked)
            while low <= high:
                mid = (low + high) // 2
                retained_non_focal = {sid for sid, _ in non_focal_ranked[:mid]}
                retained_set = focal_ids | retained_non_focal

                candidate_text, collapsed, omitted = cls._render_slice_nodes(
                    source_lines=source_lines,
                    graph=graph,
                    focal_ids=focal_ids,
                    retained_ids=retained_set,
                    include_docs=include_docs,
                )
                t_count = estimate_tokens(candidate_text)

                if t_count < max_tokens:
                    if best_slice is None or t_count > best_tokens or (mid > 0 and not best_collapsed):
                        best_slice = candidate_text
                        best_tokens = t_count
                        best_collapsed = collapsed
                        best_omitted = omitted
                    low = mid + 1
                else:
                    high = mid - 1

            if best_slice is not None and best_tokens < max_tokens:
                break

        if best_slice is None:
            best_slice, best_collapsed, best_omitted = cls._multi_focal_compress(
                graph=graph,
                focal_ids=focal_ids,
                max_tokens=max_tokens,
            )
            best_tokens = estimate_tokens(best_slice)

        orig_len = max(len(source_code), 1)
        ratio = round(len(best_slice) / orig_len, 4)

        return SliceResult(
            sliced_code=best_slice,
            token_count=best_tokens,
            focal_symbols=list(focal_ids),
            collapsed_symbols=best_collapsed,
            omitted_symbols=best_omitted,
            compression_ratio=ratio,
        )

    @classmethod
    def _multi_focal_compress(
        cls,
        graph: SymbolGraph,
        focal_ids: Set[str],
        max_tokens: int,
    ) -> Tuple[str, List[str], List[str]]:
        """Preserva le firme di tutti i simboli focali senza troncare la sintassi."""
        rendered_parts: List[str] = []
        collapsed: List[str] = []
        omitted: List[str] = []

        for fid in sorted(focal_ids):
            node = graph.nodes.get(fid)
            if node:
                sig = node.signature or f"def {node.name}(): ..."
                rendered_parts.append(f"{sig}\n    ...")
                collapsed.append(fid)

        text = "\n\n".join(rendered_parts) + "\n"
        if estimate_tokens(text) > max_tokens:
            names = [f"# {graph.nodes[f].name}" for f in focal_ids if f in graph.nodes]
            text = "\n".join(names[:10]) + "\n"

        return text, collapsed, omitted

    @classmethod
    def _render_slice_nodes(
        cls,
        source_lines: List[str],
        graph: SymbolGraph,
        focal_ids: Set[str],
        retained_ids: Set[str],
        include_docs: bool,
    ) -> Tuple[str, List[str], List[str]]:
        collapsed: List[str] = []
        omitted: List[str] = []

        header_lines: List[str] = []
        rendered_blocks: List[str] = []

        for _, node in graph.nodes.items():
            if node.symbol_type == SymbolType.IMPORT:
                if node.raw_source:
                    header_lines.append(node.raw_source.rstrip())

        if header_lines:
            rendered_blocks.append("\n".join(sorted(set(header_lines))))

        top_level_nodes = [
            n for n in graph.nodes.values()
            if n.parent_id is None and n.symbol_type not in (SymbolType.IMPORT, SymbolType.MODULE)
        ]
        top_level_nodes.sort(key=lambda n: n.line_start)

        for t_node in top_level_nodes:
            is_focal = t_node.id in focal_ids
            children = [n for n in graph.nodes.values() if n.parent_id == t_node.id]
            has_focal_child = any(c.id in focal_ids for c in children)
            has_retained_child = any(c.id in retained_ids for c in children)

            if is_focal and not children:
                raw = t_node.raw_source or ""
                rendered_blocks.append(raw.rstrip())
            elif is_focal and children:
                skeleton = cls._render_node_skeleton(
                    t_node, graph, focal_ids, retained_ids, include_docs, collapsed, omitted
                )
                if skeleton:
                    rendered_blocks.append(skeleton)
            elif t_node.id in retained_ids or has_focal_child or has_retained_child:
                skeleton = cls._render_node_skeleton(
                    t_node, graph, focal_ids, retained_ids, include_docs, collapsed, omitted
                )
                if skeleton:
                    rendered_blocks.append(skeleton)
            else:
                omitted.append(t_node.id)

        slice_output = "\n\n".join(rendered_blocks) + "\n"
        return slice_output, collapsed, omitted

    @classmethod
    def _render_node_skeleton(
        cls,
        node: SymbolNode,
        graph: SymbolGraph,
        focal_ids: Set[str],
        retained_ids: Set[str],
        include_docs: bool,
        collapsed_acc: List[str],
        omitted_acc: List[str],
    ) -> str:
        if node.symbol_type == SymbolType.CLASS:
            lines: List[str] = [node.signature or f"class {node.name}:"]
            if include_docs and node.docstring:
                lines.append(f'    """{node.docstring.strip()}"""')

            children = [n for n in graph.nodes.values() if n.parent_id == node.id]
            children.sort(key=lambda n: n.line_start)

            if not children:
                lines.append("    ...")
            else:
                for child in children:
                    if child.id in focal_ids:
                        child_src = child.raw_source or f"def {child.name}(): ..."
                        indented = "\n".join("    " + l if l.strip() else "" for l in child_src.splitlines())
                        lines.append(indented)
                    elif child.id in retained_ids:
                        collapsed_acc.append(child.id)
                        child_sig = child.signature or f"def {child.name}():"
                        lines.append(f"    {child_sig}")
                        if include_docs and child.docstring:
                            lines.append(f'        """{child.docstring.strip()}"""')
                        lines.append("        ...")
                    else:
                        omitted_acc.append(child.id)
            return "\n".join(lines)

        elif node.symbol_type in (SymbolType.FUNCTION, SymbolType.ASYNC_FUNCTION):
            collapsed_acc.append(node.id)
            lines = [node.signature or f"def {node.name}():"]
            if include_docs and node.docstring:
                lines.append(f'    """{node.docstring.strip()}"""')
            lines.append("    ...")
            return "\n".join(lines)

        elif node.symbol_type == SymbolType.CONSTANT:
            return node.signature or f"{node.name} = ..."

        return ""


# ============================================================================
# INCREMENTAL PER-FILE CACHE & ATOMIC RENAME MANAGER
# ============================================================================

class AtomicCacheManager:
    """
    Gestisce la lettura e scrittura atomica della cache in %TEMP%\\nk_diagnostics\\.
    Usa file temporanei univoci e os.replace con retry contro WinError 32.
    """

    @classmethod
    def get_default_cache_path(cls) -> Path:
        cache_dir = Path(tempfile.gettempdir()) / "nk_diagnostics"
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cache_dir / "repo_map_cache.json"

    @classmethod
    def save_atomic(cls, payload: Dict[str, Any], cache_path: Path, max_retries: int = 8) -> bool:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        temp_file = cache_path.parent / f"repo_map_cache.{uuid.uuid4().hex}.tmp"
        try:
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
            for attempt in range(max_retries):
                try:
                    os.replace(temp_file, cache_path)
                    return True
                except (PermissionError, OSError):
                    time.sleep(0.01 * (attempt + 1))
            return False
        except Exception:
            return False
        finally:
            if temp_file.exists():
                try:
                    temp_file.unlink()
                except Exception:
                    pass

    @classmethod
    def load_safe(cls, cache_path: Path, max_retries: int = 5) -> Optional[Dict[str, Any]]:
        if not cache_path.exists():
            return None
        for attempt in range(max_retries):
            try:
                with open(cache_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except (PermissionError, json.JSONDecodeError):
                time.sleep(0.01 * (2 ** attempt))
            except Exception:
                return None
        return None


# ============================================================================
# HIGH-DENSITY REPO-MAP GENERATOR (TWO-TIER CLUSTERING)
# ============================================================================

class RepoMapGenerator:
    """
    Genera la High-Density AST Repo-Map.
    Coordina il parsing incrementale, PageRank con archi cross-modulo e clustering.
    """

    SUPPORTED_EXTS = {".py", ".js", ".ts", ".jsx", ".tsx", ".css", ".html"}
    EXCLUDED_DIRS = {
        ".venv",
        ".git",
        "__pycache__",
        "node_modules",
        ".staging",
        ".pytest_cache",
        ".wal",
        "NK_External_Projects",
        "NK_Hub",
        "01_Agenti_Skill_e_Regole",
        "nk_docs_and_setup",
        "google-docs-mcp",
        "Output Business Keystone",
        "Antigravity model",
        "fonti",
        "scratch",
        "test_scratch",
        "System_Documentation",
    }

    @classmethod
    def build_map(cls, root_dir: Path, config: Optional[RepoMapConfig] = None) -> RepoMapResult:
        """Costruisce la mappa normalizzando i percorsi in formato POSIX."""
        return cls.generate(root_dir=root_dir, config=config)

    @classmethod
    def generate(cls, root_dir: Path, config: Optional[RepoMapConfig] = None) -> RepoMapResult:
        start_time = time.perf_counter()
        config = config or RepoMapConfig()
        cache_path = Path(config.cache_dir) if config.cache_dir else AtomicCacheManager.get_default_cache_path()

        cached_payload = AtomicCacheManager.load_safe(cache_path) if config.cache_enabled else None
        cached_files = (cached_payload or {}).get("files", {})

        file_map: Dict[str, Path] = {}
        for dirpath, dirnames, filenames in os.walk(root_dir, topdown=True):
            dirnames[:] = [d for d in dirnames if d not in cls.EXCLUDED_DIRS]
            dpath = Path(dirpath)
            for fname in filenames:
                p = dpath / fname
                if p.suffix.lower() in cls.SUPPORTED_EXTS:
                    try:
                        rel_parts = p.relative_to(root_dir).parts
                    except ValueError:
                        rel_parts = p.parts
                    if any(part in cls.EXCLUDED_DIRS for part in rel_parts):
                        continue
                    rel_key = str(p.relative_to(root_dir)).replace("\\", "/")
                    file_map[rel_key] = p

        staging_root = root_dir / ".staging"
        if staging_root.is_dir():
            non_staging_excluded = cls.EXCLUDED_DIRS - {".staging"}
            for sub_name in ("scripts", "tests"):
                sub_dir = staging_root / sub_name
                if not sub_dir.is_dir():
                    continue
                for p in sub_dir.rglob("*"):
                    if p.is_file() and p.suffix.lower() in cls.SUPPORTED_EXTS:
                        rel_parts = p.relative_to(staging_root).parts
                        if any(part in non_staging_excluded for part in rel_parts):
                            continue
                        rel_key = str(p.relative_to(staging_root)).replace("\\", "/")
                        file_map[rel_key] = p

        master_graph = SymbolGraph()
        new_cached_files: Dict[str, Any] = {}
        hits = 0

        for rel_str, file_path in sorted(file_map.items()):
            mtime = file_path.stat().st_mtime
            size = file_path.stat().st_size

            c_entry = cached_files.get(rel_str)
            if c_entry and c_entry.get("mtime") == mtime and c_entry.get("size") == size and "edges" in c_entry:
                nodes_data = c_entry.get("nodes", [])
                for nd in nodes_data:
                    try:
                        node = SymbolNode.model_validate(nd)
                        master_graph.add_node(node)
                    except Exception:
                        pass
                edges_data = c_entry.get("edges", [])
                for ed in edges_data:
                    try:
                        edge = SymbolEdge.model_validate(ed)
                        master_graph.add_edge(edge)
                    except Exception:
                        pass
                new_cached_files[rel_str] = c_entry
                hits += 1
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            file_nodes: List[SymbolNode] = []
            file_edges: List[SymbolEdge] = []
            file_scope_calls: Dict[str, List[str]] = {}
            if file_path.suffix.lower() == ".py":
                lines = content.splitlines(keepends=True)
                tree, _ = ResilientParser.parse_safe(content, filename=rel_str)
                extractor = SymbolExtractor(module_path=rel_str, source_lines=lines)
                if tree:
                    extractor.visit(tree)
                for node in extractor.graph.nodes.values():
                    master_graph.add_node(node)
                    file_nodes.append(node)
                for edge in extractor.graph.edges:
                    master_graph.add_edge(edge)
                    file_edges.append(edge)
                file_scope_calls = {
                    k: sorted(v) for k, v in extractor.scope_calls.items()
                }
            elif config.polyglot:
                p_nodes = PolyglotExtractor.extract_symbols(rel_str, content)
                for node in p_nodes:
                    master_graph.add_node(node)
                    file_nodes.append(node)

            new_cached_files[rel_str] = {
                "abs_path": str(file_path),
                "mtime": mtime,
                "size": size,
                "nodes": [n.model_dump() for n in file_nodes],
                "edges": [e.model_dump() for e in file_edges],
                "scope_calls": file_scope_calls,
            }

        cls._link_cross_module_edges(master_graph)

        if config.cache_enabled:
            AtomicCacheManager.save_atomic({"version": "3.0.0", "files": new_cached_files}, cache_path)

        focal_ids: Set[str] = set()
        clean_focals = [f.replace("\\", "/") for f in config.focal_files]
        for fid in master_graph.nodes:
            if any(cf in fid for cf in clean_focals):
                focal_ids.add(fid)

        pr_result = PersonalizedPageRank.compute(master_graph, target_symbol_ids=focal_ids)

        formatted_map, final_tokens = cls._render_two_tier_map(
            root_dir=root_dir,
            graph=master_graph,
            pr_scores=pr_result.scores,
            focal_ids=focal_ids,
            max_tokens=config.max_tokens,
        )

        elapsed = round((time.perf_counter() - start_time) * 1000, 2)
        return RepoMapResult(
            content=formatted_map,
            token_count=final_tokens,
            files_scanned=len(file_map),
            cached_hits=hits,
            elapsed_ms=elapsed,
            focal_files=config.focal_files,
        )

    @classmethod
    def _link_cross_module_edges(cls, graph: SymbolGraph) -> None:
        """Collega gli import ai simboli definiti in altri moduli del grafo."""
        name_to_defs: Dict[str, List[SymbolNode]] = {}
        module_stem_to_defs: Dict[str, List[SymbolNode]] = {}

        for node in graph.nodes.values():
            if node.symbol_type != SymbolType.IMPORT:
                name_to_defs.setdefault(node.name, []).append(node)
                stem = Path(node.module_path).stem
                module_stem_to_defs.setdefault(stem, []).append(node)

        for node in list(graph.nodes.values()):
            if node.symbol_type != SymbolType.IMPORT:
                continue
            target_candidates: List[SymbolNode] = []
            if node.name in name_to_defs:
                target_candidates.extend(name_to_defs[node.name])
            if node.name in module_stem_to_defs:
                target_candidates.extend(module_stem_to_defs[node.name])

            for target in target_candidates:
                if target.module_path != node.module_path:
                    graph.add_edge(
                        SymbolEdge(
                            source_id=node.id,
                            target_id=target.id,
                            edge_type=EdgeType.IMPORT_USAGE,
                            weight=1.2,
                        )
                    )

    @classmethod
    def _compact_sig_for_ste100(cls, sig: str, max_words: int = 16) -> str:
        """Garantisce che ogni firma renderizzata rispetti il limite di 20 parole STE100."""
        words = [w for w in sig.split() if any(ch.isalpha() for ch in w)]
        if len(words) <= max_words:
            return sig
        m = re.match(r"^((?:async\s+)?def\s+[a-zA-Z0-9_]+)\((.*)\)(.*)$", sig)
        if m:
            prefix, raw_args, suffix = m.group(1), m.group(2), m.group(3)
            arg_names = [
                a.split(":")[0].split("=")[0].strip()
                for a in raw_args.split(",")
                if a.strip()
            ]
            short_args = ", ".join(arg_names[:6])
            if len(arg_names) > 6:
                short_args += ", ..."
            short_sig = f"{prefix}({short_args}){suffix}"
            if len([w for w in short_sig.split() if any(ch.isalpha() for ch in w)]) <= max_words:
                return short_sig
            return f"{prefix}({short_args})"
        return " ".join(sig.split()[:max_words])

    @classmethod
    def _render_expanded_module(cls, mod: str, syms: List[SymbolNode]) -> str:
        mod_lines = [f"## 📄 {mod}"]
        classes = [s for s in syms if s.symbol_type == SymbolType.CLASS]
        for cls_node in classes:
            cls_sig = cls._compact_sig_for_ste100(cls_node.signature or f"class {cls_node.name}:")
            mod_lines.append(f"  {cls_sig}")
            methods = [s for s in syms if s.parent_id == cls_node.id and s.symbol_type == SymbolType.METHOD]
            for m in methods:
                m_sig = cls._compact_sig_for_ste100(m.signature or f"def {m.name}(): ...")
                mod_lines.append(f"    {m_sig}")
        functions = [
            s for s in syms
            if s.symbol_type in (SymbolType.FUNCTION, SymbolType.ASYNC_FUNCTION) and s.parent_id is None
        ]
        for fn in functions:
            fn_sig = cls._compact_sig_for_ste100(fn.signature or f"def {fn.name}(): ...")
            mod_lines.append(f"  {fn_sig}")
        if not classes and not functions:
            other_syms = [s for s in syms if s.symbol_type != SymbolType.IMPORT]
            for osym in other_syms[:5]:
                mod_lines.append(f"  {cls._compact_sig_for_ste100(osym.signature or osym.name)}")
        mod_lines.append("")
        return "\n".join(mod_lines)

    @classmethod
    def _render_inline_compact_module(cls, mod: str, syms: List[SymbolNode]) -> str:
        lines = [f"## 📄 {mod}"]
        classes = [s for s in syms if s.symbol_type == SymbolType.CLASS]
        for cls_node in classes:
            methods = [s for s in syms if s.parent_id == cls_node.id and s.symbol_type == SymbolType.METHOD]
            if methods:
                m_names = [m.name for m in methods]
                for i in range(0, len(m_names), 8):
                    chunk = m_names[i : i + 8]
                    lines.append(f"  class {cls_node.name}: [{', '.join(chunk)}]")
            else:
                consts = [s for s in syms if s.parent_id == cls_node.id and s.symbol_type == SymbolType.CONSTANT]
                if consts:
                    c_names = [c.name for c in consts]
                    for i in range(0, len(c_names), 8):
                        chunk = c_names[i : i + 8]
                        lines.append(f"  class {cls_node.name}: [{', '.join(chunk)}]")
                else:
                    lines.append(f"  class {cls_node.name}: []")

        functions = [
            s for s in syms
            if s.symbol_type in (SymbolType.FUNCTION, SymbolType.ASYNC_FUNCTION) and s.parent_id is None
        ]
        if functions:
            fn_names = [fn.name for fn in functions]
            for i in range(0, len(fn_names), 8):
                chunk = fn_names[i : i + 8]
                lines.append(f"  functions: [{', '.join(chunk)}]")

        if not classes and not functions:
            other_syms = [s for s in syms if s.symbol_type != SymbolType.IMPORT]
            if other_syms:
                sym_names = [s.name for s in other_syms[:5]]
                lines.append(f"  symbols: [{', '.join(sym_names)}]")

        lines.append("")
        return "\n".join(lines)

    @classmethod
    def _render_two_tier_map(
        cls,
        root_dir: Path,
        graph: SymbolGraph,
        pr_scores: Dict[str, float],
        focal_ids: Set[str],
        max_tokens: int,
    ) -> Tuple[str, int]:
        """
        Formatta la mappa ad alta densita' con compattazione elastica a tre livelli.
        Garantisce un margine di sicurezza <= 82% di max_tokens.
        """
        modules: Dict[str, List[SymbolNode]] = {}
        for node in graph.nodes.values():
            if node.symbol_type != SymbolType.IMPORT:
                modules.setdefault(node.module_path, []).append(node)

        if not modules:
            header = "# 🗺️ HIGH-DENSITY AST REPO-MAP (Tetralogia Sovrana Snapshot)\n"
            return header, estimate_tokens(header)

        mod_pr_map: Dict[str, float] = {}
        module_scores: List[Tuple[str, float, bool]] = []
        for mod, syms in modules.items():
            is_focal = any(s.id in focal_ids for s in syms)
            base_pr = max((pr_scores.get(s.id, 0.0) for s in syms), default=0.0)
            mod_pr_map[mod] = base_pr
            score = base_pr
            if is_focal:
                score += 1000.0
            has_cls = any(s.symbol_type == SymbolType.CLASS for s in syms)
            if has_cls:
                score += 0.01
            module_scores.append((mod, score, is_focal))

        module_scores.sort(key=lambda x: x[1], reverse=True)

        header = "# 🗺️ HIGH-DENSITY AST REPO-MAP (Tetralogia Sovrana Snapshot)\n\n"
        target_budget = min(max_tokens, int(max_tokens * 0.82))
        tier1_budget = max(40, int(target_budget * 0.55))

        tier1_blocks: List[str] = []
        tier1_mods: Set[str] = set()

        for mod, score, is_focal in module_scores:
            syms = modules[mod]
            classes = [s for s in syms if s.symbol_type == SymbolType.CLASS]
            methods = [s for s in syms if s.symbol_type == SymbolType.METHOD]
            functions = [
                s for s in syms
                if s.symbol_type in (SymbolType.FUNCTION, SymbolType.ASYNC_FUNCTION) and s.parent_id is None
            ]

            is_large = (
                len(classes) >= 3 or
                (len(classes) >= 1 and len(methods) >= 5) or
                (len(classes) + len(functions) >= 7)
            )

            if not is_large or is_focal:
                exp_block = cls._render_expanded_module(mod, syms)
                cand = header + "\n".join(tier1_blocks + [exp_block])
                if estimate_tokens(cand) <= tier1_budget:
                    tier1_blocks.append(exp_block)
                    tier1_mods.add(mod)
                    continue

            inline_block = cls._render_inline_compact_module(mod, syms)
            cand = header + "\n".join(tier1_blocks + [inline_block])
            if estimate_tokens(cand) <= tier1_budget:
                tier1_blocks.append(inline_block)
                tier1_mods.add(mod)
                continue
            elif not tier1_blocks:
                cand_lines = inline_block.splitlines()
                trimmed = [cand_lines[0]]
                for l in cand_lines[1:]:
                    test_t = header + "\n".join(tier1_blocks + ["\n".join(trimmed + [l, ""])])
                    if estimate_tokens(test_t) <= tier1_budget:
                        trimmed.append(l)
                    else:
                        break
                if len(trimmed) > 1:
                    trimmed.append("")
                    tier1_blocks.append("\n".join(trimmed))
                    tier1_mods.add(mod)
                    continue

        tier2_mods = [m for m, _, _ in module_scores if m not in tier1_mods]
        tier2_header = "### 📦 Moduli Secondari (Riepilogo Compatto)\n" if tier2_mods else ""
        tier2_lines: List[str] = []
        remaining_mods: List[str] = []

        tier2_mods.sort(
            key=lambda m: (
                any(s.symbol_type == SymbolType.CLASS for s in modules[m]),
                mod_pr_map.get(m, 0.0),
            ),
            reverse=True,
        )

        for idx, mod in enumerate(tier2_mods):
            syms = modules[mod]
            classes = [s.name for s in syms if s.symbol_type == SymbolType.CLASS]
            fns = [
                s.name for s in syms
                if s.symbol_type in (SymbolType.FUNCTION, SymbolType.ASYNC_FUNCTION) and s.parent_id is None
            ]
            key_syms = classes + fns
            if not key_syms:
                key_syms = [s.name for s in syms if s.symbol_type != SymbolType.IMPORT]
            top_syms = classes[:8] if len(classes) >= 3 else key_syms[:3]
            line = f"- `{mod}`: [{', '.join(top_syms)}]" if top_syms else f"- `{mod}`: []"

            unprocessed = tier2_mods[idx + 1:]
            rem_groups: Dict[str, List[str]] = {}
            for u in unprocessed:
                p_u = Path(u)
                d = p_u.parent.as_posix()
                rem_groups.setdefault(d, []).append(p_u.name)
            rem_folder_lines: List[str] = []
            for d, fnames in rem_groups.items():
                prefix = "root/*" if (d == "." or not d) else f"{d}/*"
                for i in range(0, len(fnames), 8):
                    chunk = fnames[i : i + 8]
                    rem_folder_lines.append(f"- `{prefix}`: {', '.join(chunk)}")

            test_map = (
                header
                + "\n".join(tier1_blocks)
                + "\n"
                + tier2_header
                + "\n".join(tier2_lines + [line] + rem_folder_lines)
            )
            if estimate_tokens(test_map) <= target_budget:
                tier2_lines.append(line)
            else:
                remaining_mods = tier2_mods[idx:]
                break

        if remaining_mods:
            rem_groups = {}
            for u in remaining_mods:
                p_u = Path(u)
                d = p_u.parent.as_posix()
                rem_groups.setdefault(d, []).append(p_u.name)

            unadded_dirs: List[str] = []
            for d, fnames in rem_groups.items():
                prefix = "root/*" if (d == "." or not d) else f"{d}/*"
                f_chunks = [
                    f"- `{prefix}`: {', '.join(fnames[i : i + 8])}"
                    for i in range(0, len(fnames), 8)
                ]
                test_map = (
                    header
                    + "\n".join(tier1_blocks)
                    + "\n"
                    + tier2_header
                    + "\n".join(tier2_lines + f_chunks)
                )
                if estimate_tokens(test_map) <= target_budget:
                    tier2_lines.extend(f_chunks)
                else:
                    unadded_dirs.append(prefix)

            if unadded_dirs:
                for i in range(0, len(unadded_dirs), 8):
                    chunk_dirs = unadded_dirs[i : i + 8]
                    ultra_line = "- `" + "`, `".join(chunk_dirs) + "`"
                    tier2_lines.append(ultra_line)

        blocks = [header.rstrip(), ""]
        if tier1_blocks:
            blocks.extend(tier1_blocks)
        if tier2_header and tier2_lines:
            blocks.append(tier2_header.rstrip())
            blocks.extend(tier2_lines)

        final_content = "\n".join(blocks).strip() + "\n"
        final_tokens = estimate_tokens(final_content)

        if final_tokens > max_tokens:
            cand_lines = final_content.splitlines()
            trimmed = []
            for l in cand_lines:
                cand_str = "\n".join(trimmed + [l]) + "\n"
                if estimate_tokens(cand_str) <= max_tokens:
                    trimmed.append(l)
                else:
                    break
            final_content = "\n".join(trimmed).strip() + "\n"
            final_tokens = estimate_tokens(final_content)

        return final_content, final_tokens


# ============================================================================
# GRADUATED SKILL ADAPTER
# ============================================================================

class GraduatedSkillAdapter:
    """Fornisce la graduazione del budget token in base alla modalita' e alla skill."""

    BLACKLIST = {"NK-Scribe", "NK-Episodic-Memory-Engine", "NK-Agent-Instruction-Forge"}

    @classmethod
    def get_token_budget(cls, skill_name: str, speed_mode: str = "auto") -> int:
        if skill_name in cls.BLACKLIST:
            return 0
        mode = speed_mode.lower()
        if "argon_mode_c" in mode:
            return 512
        if "argon_mode_b" in mode:
            return 1500
        if "argon_mode_a" in mode:
            return 4000
        if "mode_c" in mode or "vibe" in mode:
            return 256
        elif "mode_b" in mode or "fast" in mode:
            return 512
        else:
            return 1024


# ============================================================================
# CLI INTERFACE & SNAPSHOT EXPORTER
# ============================================================================

def export_markdown_snapshot(root_dir: Path, output_path: Path, max_tokens: int = 1024) -> RepoMapResult:
    """Genera e scrive autonomamente lo snapshot canonico repo_map.md."""
    cfg = RepoMapConfig(max_tokens=max_tokens, polyglot=True)
    res = RepoMapGenerator.generate(root_dir=root_dir, config=cfg)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(res.content, encoding="utf-8")
    return res


def query_symbol_subgraph(
    symbol_name: str,
    root: Optional[Path] = None,
    root_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Estrae definizioni, chiamanti (callers) e chiamati (callees) per un simbolo senza modificare repo_map.md."""
    effective_root = root_dir if root_dir is not None else root
    root_dir = Path(effective_root).resolve() if effective_root is not None else Path(".").resolve()
    target_sym = str(symbol_name or "").strip()
    if not target_sym:
        return {
            "symbol": "",
            "found": False,
            "definitions": [],
            "callers": [],
            "callees": [],
        }

    file_map: Dict[str, Path] = {}
    for dirpath, dirnames, filenames in os.walk(root_dir, topdown=True):
        dirnames[:] = [d for d in dirnames if d not in RepoMapGenerator.EXCLUDED_DIRS]
        dpath = Path(dirpath)
        for fname in filenames:
            if fname.endswith(".py"):
                p = dpath / fname
                try:
                    rel_parts = p.relative_to(root_dir).parts
                except ValueError:
                    rel_parts = p.parts
                if any(part in RepoMapGenerator.EXCLUDED_DIRS for part in rel_parts):
                    continue
                rel_key = str(p.relative_to(root_dir)).replace("\\", "/")
                file_map[rel_key] = p

    master_graph = SymbolGraph()
    staging_root = root_dir / ".staging"
    if staging_root.exists() and staging_root.is_dir():
        staging_excluded = RepoMapGenerator.EXCLUDED_DIRS - {".staging"}
        for dirpath, dirnames, filenames in os.walk(staging_root, topdown=True):
            dirnames[:] = [d for d in dirnames if d not in staging_excluded]
            dpath = Path(dirpath)
            for fname in filenames:
                if fname.endswith(".py"):
                    p = dpath / fname
                    try:
                        rel_parts = p.relative_to(staging_root).parts
                    except ValueError:
                        rel_parts = p.parts
                    if any(part in staging_excluded for part in rel_parts):
                        continue
                    rel_key = str(p.relative_to(staging_root)).replace("\\", "/")
                    file_map[rel_key] = p
    scope_calls: Dict[str, Set[str]] = {}
    node_by_id: Dict[str, SymbolNode] = {}

    cache_path = AtomicCacheManager.get_default_cache_path()
    cached_payload = AtomicCacheManager.load_safe(cache_path)
    cached_files: Dict[str, Any] = dict((cached_payload or {}).get("files", {}))
    cache_dirty = False

    for rel_str, file_path in sorted(file_map.items()):
        try:
            st = file_path.stat()
            mtime, size = st.st_mtime, st.st_size
        except OSError:
            continue

        c_entry = cached_files.get(rel_str)
        if (
            c_entry
            and c_entry.get("mtime") == mtime
            and c_entry.get("size") == size
            and c_entry.get("abs_path") == str(file_path)
            and "nodes" in c_entry
            and "edges" in c_entry
            and "scope_calls" in c_entry
        ):
            for nd in c_entry.get("nodes", []):
                try:
                    node = SymbolNode.model_validate(nd)
                    master_graph.add_node(node)
                    node_by_id[node.id] = node
                except Exception:
                    pass
            for ed in c_entry.get("edges", []):
                try:
                    master_graph.add_edge(SymbolEdge.model_validate(ed))
                except Exception:
                    pass
            for sc_id, sc_list in c_entry.get("scope_calls", {}).items():
                scope_calls[sc_id] = set(sc_list)
            continue

        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        lines = content.splitlines(keepends=True)
        tree, _ = ResilientParser.parse_safe(content, filename=rel_str)
        extractor = SymbolExtractor(module_path=rel_str, source_lines=lines)
        if tree:
            extractor.visit(tree)
        file_nodes: List[SymbolNode] = []
        file_edges: List[SymbolEdge] = []
        for node in extractor.graph.nodes.values():
            master_graph.add_node(node)
            node_by_id[node.id] = node
            file_nodes.append(node)
        for sc_id, called_names in extractor.scope_calls.items():
            scope_calls[sc_id] = set(called_names)
        for edge in extractor.graph.edges:
            master_graph.add_edge(edge)
            file_edges.append(edge)

        cached_files[rel_str] = {
            "abs_path": str(file_path),
            "mtime": mtime,
            "size": size,
            "nodes": [n.model_dump() for n in file_nodes],
            "edges": [e.model_dump() for e in file_edges],
            "scope_calls": {
                k: sorted(v) for k, v in extractor.scope_calls.items()
            },
        }
        cache_dirty = True

    if cache_dirty:
        AtomicCacheManager.save_atomic(
            {"version": "3.0.0", "files": cached_files}, cache_path
        )

    RepoMapGenerator._link_cross_module_edges(master_graph)

    matched_nodes: List[SymbolNode] = []
    for node in master_graph.nodes.values():
        if node.symbol_type == SymbolType.IMPORT:
            continue
        if (
            node.name == target_sym
            or node.id == target_sym
            or node.id.endswith(f":{target_sym}")
            or node.id.endswith(f".{target_sym}")
        ):
            matched_nodes.append(node)

    definitions: List[Dict[str, Any]] = [
        {
            "id": n.id,
            "name": n.name,
            "symbol_type": (
                n.symbol_type.value
                if hasattr(n.symbol_type, "value")
                else str(n.symbol_type)
            ),
            "module_path": n.module_path,
            "line_start": n.line_start,
            "line_end": n.line_end,
            "signature": n.signature or n.name,
        }
        for n in matched_nodes
    ]

    matched_ids = {n.id for n in matched_nodes}
    matched_names = {n.name for n in matched_nodes} | {target_sym}

    caller_ids: Set[str] = set()
    callee_names: Set[str] = set()

    for edge in master_graph.edges:
        if edge.edge_type == EdgeType.CALL:
            if edge.target_id in matched_ids:
                caller_ids.add(edge.source_id)
            if edge.source_id in matched_ids:
                tgt_n = node_by_id.get(edge.target_id)
                callee_names.add(tgt_n.name if tgt_n else edge.target_id)

    for scope_id, called_set in scope_calls.items():
        if scope_id in matched_ids:
            callee_names.update(called_set)
        elif called_set & matched_names:
            caller_ids.add(scope_id)

    callers_list: List[Dict[str, Any]] = []
    for cid in sorted(caller_ids):
        cn = node_by_id.get(cid)
        if cn:
            callers_list.append(
                {
                    "id": cn.id,
                    "name": cn.name,
                    "module_path": cn.module_path,
                    "line_start": cn.line_start,
                }
            )
        else:
            callers_list.append({"id": cid, "name": cid.split(":")[-1]})

    callees_list: List[Dict[str, Any]] = []
    for cname in sorted(callee_names):
        cdefs = [
            n
            for n in master_graph.nodes.values()
            if n.name == cname and n.symbol_type != SymbolType.IMPORT
        ]
        if cdefs:
            for cd in cdefs:
                callees_list.append(
                    {
                        "id": cd.id,
                        "name": cd.name,
                        "module_path": cd.module_path,
                        "line_start": cd.line_start,
                    }
                )
        else:
            callees_list.append({"id": cname, "name": cname})

    return {
        "symbol": target_sym,
        "found": len(definitions) > 0,
        "definitions": definitions,
        "callers": callers_list,
        "callees": callees_list,
    }


def main() -> None:
    try:
        if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    parser = argparse.ArgumentParser(description="High-Density AST Repo-Map Engine v4.7.0-STE100-Unified")
    parser.add_argument("--repo-map", action="store_true", help="Genera e stampa la repo map")
    parser.add_argument("--root", default=".", help="Directory radice da analizzare")
    parser.add_argument("--max-tokens", type=int, default=None, help="Budget massimo di token")
    parser.add_argument("--mode", default="auto", help="Modalita': auto, mode_c, mode_b, mode_a, argon_mode_*")
    parser.add_argument("--json", action="store_true", help="Output in formato JSON")
    parser.add_argument("--snapshot-out", "--export", dest="snapshot_out", type=str, help="Esporta snapshot su file")
    parser.add_argument("--focus-files", type=str, default="", help="Lista di file focali separati da virgola")
    parser.add_argument("--symbol", type=str, default=None, help="Interroga il sottografo AST per un singolo simbolo senza rigenerare repo_map.md")

    args = parser.parse_args()
    root_path = Path(args.root).resolve()

    if args.symbol:
        sub_res = query_symbol_subgraph(symbol_name=args.symbol, root=root_path)
        print(json.dumps(sub_res, indent=2, ensure_ascii=False))
        return

    focals = [f.strip() for f in args.focus_files.split(",") if f.strip()]

    effective_tokens = (
        args.max_tokens
        if args.max_tokens is not None
        else GraduatedSkillAdapter.get_token_budget("NK-Session-Controller", args.mode)
    )

    cfg = RepoMapConfig(
        max_tokens=effective_tokens,
        mode=args.mode,
        focal_files=focals,
        polyglot=True,
    )

    result = RepoMapGenerator.generate(root_dir=root_path, config=cfg)

    if args.snapshot_out:
        out_p = Path(args.snapshot_out).resolve()
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(result.content, encoding="utf-8")
        print(f"[+] Snapshot saved to: {out_p} ({result.token_count} tokens, {result.elapsed_ms}ms)")

    if args.json:
        print(json.dumps(result.model_dump(), indent=2))
    elif args.repo_map or not args.snapshot_out:
        safe_text = result.content.encode(sys.stdout.encoding or "utf-8", errors="replace").decode(
            sys.stdout.encoding or "utf-8"
        )
        print(safe_text)


if __name__ == "__main__":
    main()
