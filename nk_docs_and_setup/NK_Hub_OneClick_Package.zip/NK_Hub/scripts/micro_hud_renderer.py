# -*- coding: utf-8 -*-
"""
Renderer telemetrico Micro-HUD per NK Hub Generation 1.0.0-Generation.
Allinea HUDState con MicroUIHUDState e supporta il fallback ASCII e le metriche RSI.
"""

from __future__ import annotations

import argparse
import sys
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Sequence


def _build_cli_parser() -> argparse.ArgumentParser:
    """Costruisce il parser CLI senza importare Pydantic."""
    parser = argparse.ArgumentParser(
        description="NK Hub Generation 1.0.0-Generation Real-Time Micro-HUD Stream Renderer"
    )
    parser.add_argument("--percent", type=int, default=100)
    parser.add_argument("--mutex", type=str, default="UNLOCKED")
    parser.add_argument("--agent", type=str, default="NK-Orchestrator")
    parser.add_argument("--domain", type=str, default="DEVX")
    parser.add_argument("--ascii", action="store_true")
    parser.add_argument("--json", action="store_true")
    return parser


if __name__ == "__main__" and any(a in ("-h", "--help") for a in sys.argv[1:]):
    _build_cli_parser().parse_args()
    raise SystemExit(0)

from pydantic import BaseModel, ConfigDict, Field

_scripts_dir = Path(__file__).resolve().parent
if str(_scripts_dir) not in sys.path:
    sys.path.insert(0, str(_scripts_dir))
if _scripts_dir.parent.name == ".staging" and (_scripts_dir / "_internal").is_dir():
    import _internal as _stg_internal_pkg

    _stg_int_str = str(_scripts_dir / "_internal")
    if _stg_int_str not in _stg_internal_pkg.__path__:
        _stg_internal_pkg.__path__.insert(0, _stg_int_str)

from _internal.nk_common.constants import VERSION  # noqa: E402
from _internal.nk_common.paths import reconfigure_streams  # noqa: E402

if TYPE_CHECKING:
    from schemas.nk_ipc_contracts import MicroUIHUDState
else:
    MicroUIHUDState: Any = Any

_IPC_HUD_LOCK = threading.Lock()
_CACHED_MICRO_UI_HUD_STATE: Any = None


def _get_micro_ui_hud_state_cls() -> Any:
    """Carica pigramente MicroUIHUDState da schemas.nk_ipc_contracts."""
    global _CACHED_MICRO_UI_HUD_STATE
    if _CACHED_MICRO_UI_HUD_STATE is not None:
        return _CACHED_MICRO_UI_HUD_STATE
    with _IPC_HUD_LOCK:
        if _CACHED_MICRO_UI_HUD_STATE is not None:
            return _CACHED_MICRO_UI_HUD_STATE
        try:
            from schemas.nk_ipc_contracts import MicroUIHUDState as _hud_cls
        except ImportError:
            from scripts.schemas.nk_ipc_contracts import MicroUIHUDState as _hud_cls
        _CACHED_MICRO_UI_HUD_STATE = _hud_cls
        return _CACHED_MICRO_UI_HUD_STATE


HUD_DEFAULT_VERSION: str = VERSION
GateStatus = Literal["PASSED", "RUNNING", "FAILED", "PENDING", "BLOCKED", "SKIPPED"]
MutexStatus = Literal["LOCKED", "UNLOCKED", "ACQUIRING", "STALE_RECOVERED"]

GATE_SYMBOLS: Dict[GateStatus, str] = {
    "PASSED": "✓",
    "RUNNING": "⟳",
    "FAILED": "✗",
    "PENDING": "⏳",
    "BLOCKED": "⏸",
    "SKIPPED": "⊘",
}

GATE_SYMBOLS_ASCII: Dict[GateStatus, str] = {
    "PASSED": "[OK]",
    "RUNNING": "[RUN]",
    "FAILED": "[FAIL]",
    "PENDING": "[WAIT]",
    "BLOCKED": "[BLOCK]",
    "SKIPPED": "[SKIP]",
}


def is_unicode_stream_supported(stream: object = None) -> bool:
    """Verifica se lo stream di output supporta i simboli Unicode del Micro-HUD."""
    target_stream = stream or sys.stdout
    encoding = getattr(target_stream, "encoding", None)
    if not encoding:
        return True
    try:
        "▓░✓⟳✗⏳⏸⊘".encode(encoding)
        return True
    except (UnicodeEncodeError, LookupError, AttributeError):
        return False


class GateEntry(BaseModel):
    """Stato di un singolo gate visualizzato nel Micro-HUD."""

    model_config = ConfigDict(strict=True, extra="forbid")

    id: str
    status: GateStatus = "PENDING"
    description: Optional[str] = None


class HUDState(BaseModel):
    """Stato interno del renderer Micro-HUD sincronizzabile con MicroUIHUDState."""

    model_config = ConfigDict(strict=True, extra="forbid")

    version: str = HUD_DEFAULT_VERSION
    progress_percent: int = Field(default=0, ge=0, le=100)
    bar_width: int = Field(default=10, ge=5, le=50)
    gates: List[GateEntry] = Field(default_factory=list)
    mutex_status: MutexStatus = "UNLOCKED"
    agent_id: Optional[str] = None
    domain: Optional[str] = None
    tier1_tokens_used: Optional[int] = Field(default=None, ge=0)
    tier1_token_cap: int = Field(default=350, ge=1)
    elapsed_seconds: Optional[float] = Field(default=None, ge=0.0)
    rsi_delta: Optional[float] = Field(default=None, ge=0.0)
    rsi_fitness_q: Optional[float] = Field(default=None, ge=0.0, le=100.0)


class MicroHUDRenderer:
    """Genera stringhe di stato compatte per la telemetria della sessione."""

    def __init__(
        self,
        version: str = HUD_DEFAULT_VERSION,
        default_gates: Optional[Sequence[str]] = ("G1", "G2", "G3", "G4", "G5"),
        bar_width: int = 10,
        ascii_mode: Optional[bool] = None,
    ) -> None:
        reconfigure_streams()
        gates_list = [
            GateEntry(id=gid, status="PENDING") for gid in (default_gates or [])
        ]
        self.state = HUDState(
            version=version,
            progress_percent=0,
            bar_width=bar_width,
            gates=gates_list,
            mutex_status="UNLOCKED",
        )
        self.ascii_mode = ascii_mode

    def set_progress(self, percent: int) -> MicroHUDRenderer:
        """Aggiorna la percentuale di avanzamento tra 0 e 100."""
        self.state.progress_percent = max(0, min(100, int(percent)))
        return self

    def set_gate(
        self,
        gate_id: str,
        status: GateStatus,
        description: Optional[str] = None,
    ) -> MicroHUDRenderer:
        """Aggiorna o aggiunge lo stato di un gate specifico."""
        for g in self.state.gates:
            if g.id == gate_id:
                g.status = status
                if description:
                    g.description = description
                return self
        self.state.gates.append(
            GateEntry(id=gate_id, status=status, description=description)
        )
        return self

    def set_mutex(self, status: MutexStatus) -> MicroHUDRenderer:
        """Imposta lo stato corrente del mutex Win32."""
        self.state.mutex_status = status
        return self

    def set_agent_context(
        self,
        agent_id: str,
        domain: Optional[str] = None,
    ) -> MicroHUDRenderer:
        """Imposta l'identificatore dell'agente attivo e il relativo dominio."""
        self.state.agent_id = agent_id
        self.state.domain = domain
        return self

    def set_rsi_metrics(self, delta_k: float, fitness_q: float) -> MicroHUDRenderer:
        """Imposta le metriche di convergenza RSI (Delta_k e Fitness Q)."""
        self.state.rsi_delta = max(0.0, float(delta_k))
        self.state.rsi_fitness_q = max(0.0, min(100.0, float(fitness_q)))
        return self

    def to_ipc_state(
        self,
        session_id: str = "nk_session",
        hud_status: Literal["IDLE", "RUNNING", "BLOCKED", "ERROR", "COMMITTED"] = "RUNNING",
        active_task: str = "active_op",
    ) -> MicroUIHUDState:
        """Esporta lo stato corrente nel contratto IPC MicroUIHUDState."""
        metrics: Dict[str, float] = {}
        if self.state.rsi_delta is not None:
            metrics["rsi_delta"] = float(self.state.rsi_delta)
        if self.state.rsi_fitness_q is not None:
            metrics["rsi_fitness_q"] = float(self.state.rsi_fitness_q)
        if self.state.tier1_tokens_used is not None:
            metrics["tier1_tokens_used"] = float(self.state.tier1_tokens_used)

        hud_cls = _get_micro_ui_hud_state_cls()
        return hud_cls(
            session_id=session_id,
            hud_status=hud_status,
            active_task=active_task,
            progress_pct=float(self.state.progress_percent),
            metrics=metrics,
            updated_at=time.time(),
        )

    def _build_progress_bar(self, ascii_mode: bool = False) -> str:
        width = self.state.bar_width
        filled_count = int(round((self.state.progress_percent / 100.0) * width))
        filled_count = max(0, min(width, filled_count))
        empty_count = width - filled_count
        if ascii_mode:
            bar = "#" * filled_count + "-" * empty_count
        else:
            bar = "▓" * filled_count + "░" * empty_count
        return f"{bar} {self.state.progress_percent}%"

    def _build_gates_string(self, ascii_mode: bool = False) -> str:
        if not self.state.gates:
            return ""
        rendered_gates = []
        for g in self.state.gates:
            if ascii_mode:
                raw_sym = GATE_SYMBOLS_ASCII.get(g.status, "[WAIT]")
                sym = raw_sym.strip("[]")
                rendered_gates.append(f"[{g.id}:{sym}]")
            else:
                symbol = GATE_SYMBOLS.get(g.status, "⏳")
                rendered_gates.append(f"[{g.id}:{symbol}]")
        return "GATES: " + " ".join(rendered_gates)

    def _render_internal(
        self,
        include_extras: bool = False,
        ascii_mode: bool = False,
    ) -> str:
        bar_part = self._build_progress_bar(ascii_mode=ascii_mode)
        gates_part = self._build_gates_string(ascii_mode=ascii_mode)
        mutex_part = f"MUTEX: {self.state.mutex_status}"

        segments = [f"[NK-HUD {self.state.version}] {bar_part}"]
        if gates_part:
            segments.append(gates_part)
        segments.append(mutex_part)

        if include_extras:
            if self.state.rsi_delta is not None and self.state.rsi_fitness_q is not None:
                segments.append(
                    f"RSI: Δ={self.state.rsi_delta:.1f} Q={self.state.rsi_fitness_q:.1f}"
                )
            if self.state.tier1_tokens_used is not None:
                segments.append(
                    f"TIER1: {self.state.tier1_tokens_used}/{self.state.tier1_token_cap} tok"
                )
            if self.state.agent_id:
                dom_suffix = f" [{self.state.domain}]" if self.state.domain else ""
                segments.append(f"AGENT: {self.state.agent_id}{dom_suffix}")
            if self.state.elapsed_seconds is not None:
                segments.append(f"T: {self.state.elapsed_seconds:.2f}s")

        return " | ".join(segments)

    def render(
        self,
        include_extras: bool = False,
        ascii_mode: Optional[bool] = None,
    ) -> str:
        """Restituisce la stringa HUD con fallback automatico in ASCII."""
        use_ascii = (
            self.ascii_mode
            if self.ascii_mode is not None
            else not is_unicode_stream_supported()
        )
        if ascii_mode is not None:
            use_ascii = ascii_mode

        if not use_ascii:
            try:
                candidate = self._render_internal(
                    include_extras=include_extras,
                    ascii_mode=False,
                )
                enc = getattr(sys.stdout, "encoding", None) or "utf-8"
                candidate.encode(enc)
                return candidate
            except (UnicodeEncodeError, LookupError):
                use_ascii = True

        return self._render_internal(include_extras=include_extras, ascii_mode=True)


def main() -> int:
    """Interfaccia CLI per il renderer telemetrico Micro-HUD."""
    reconfigure_streams()
    parser = _build_cli_parser()
    args = parser.parse_args()

    renderer = MicroHUDRenderer(ascii_mode=args.ascii if args.ascii else None)
    renderer.set_progress(args.percent)
    renderer.set_mutex(args.mutex)
    renderer.set_agent_context(args.agent, args.domain)
    for g in ("G1", "G2", "G3", "G4", "G5"):
        renderer.set_gate(g, "PASSED")

    if args.json:
        print(renderer.state.model_dump_json(indent=2))
    else:
        print(renderer.render(ascii_mode=args.ascii if args.ascii else None))
    return 0


if __name__ == "__main__":
    sys.exit(main())
